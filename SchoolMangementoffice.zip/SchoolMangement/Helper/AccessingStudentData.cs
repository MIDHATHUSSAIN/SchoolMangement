﻿using SchoolMangement.Classes;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace SchoolMangement.Helper
{
    
    class AccessingStudentData
    {
        string path = @"C:\Users\mhussain\Downloads\SchoolMangementHomiii\SchoolMangement\SchoolMangement\Model\StudentsData.xml";
        XmlRootAttribute xRoot = new XmlRootAttribute();
        ObservableCollection<Student> students;
        public ObservableCollection<Student> RetrivingData()
        {
            try
            {   
                xRoot.ElementName = "Students";
                xRoot.IsNullable = true;
                XmlSerializer serializer = new XmlSerializer(typeof(ObservableCollection<Student>), xRoot);
                using (StreamReader reader = new StreamReader(path))
                {
                    var data = (ObservableCollection<Student>)serializer.Deserialize(reader);

                    return data;
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }

        }

        public void SavingData(Student StudentData)
        {
            try
            {
                xRoot.ElementName = "Students";
                xRoot.IsNullable = true;
                XmlSerializer serializer = new XmlSerializer(typeof(ObservableCollection<Student>), xRoot);

                if (File.Exists(path))
                {
                    using (StreamReader reader = new StreamReader(path))
                    {
                        students = (ObservableCollection<Student>)serializer.Deserialize(reader);
                    }
                }
                
                var a = students.Where(x => x.StudentEmail == StudentData.StudentEmail).FirstOrDefault();
                if(a != null)
                {
                    MessageBox.Show("Student with this email already exists.");
                    return;
                }
                else
                {   students.Add(StudentData);
                    using (StreamWriter writer = new StreamWriter(path))
                    {
                        serializer.Serialize(writer, students);

                    }
                    System.Windows.MessageBox.Show("Student Saved Successfully!");
                }

            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
                MessageBox.Show("Somthing went wrong");
            }

        }

        public void UpdatingData(Student StudentData)
        {
            try
            {

            }catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public void DeletingData(Student StudentData)
        {
            try
            {
                xRoot.ElementName = "Students";
                xRoot.IsNullable = true;
                XmlSerializer serializer = new XmlSerializer(typeof(ObservableCollection<Student>), xRoot);

                if (File.Exists(path))
                {
                    using (StreamReader reader = new StreamReader(path))
                    {
                        students = (ObservableCollection<Student>)serializer.Deserialize(reader);
                    }
                }

                var a = students.Where(x => x.StudentEmail == StudentData.StudentEmail).FirstOrDefault();
                if (a != null)
                {
                    students.Remove(a);
                    using (StreamWriter writer = new StreamWriter(path))
                    {
                        serializer.Serialize(writer, students);

                    }
                    System.Windows.MessageBox.Show("Student Deleted Successfully!");
                }
                
            }
            catch (Exception ex) {

                Console.WriteLine(ex.Message);
                MessageBox.Show("Somthing went wrong");
            }

        }

        
    
    }
}
