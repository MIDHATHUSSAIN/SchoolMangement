﻿using SchoolMangement.View.UserControls.FormInputs;
using SchoolMangement.ViewModel;
using System.Windows;

namespace SchoolMangement.View.Pages
{
    public partial class LoginSignUpForm 
    {
        public LoginSignUpForm()
        {
            InitializeComponent();
            
        }


    }
}
