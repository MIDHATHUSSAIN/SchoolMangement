﻿using SchoolMangement.Classes;
using System.Collections.ObjectModel;
using System.IO;
using System.Xml.Serialization;

namespace SchoolMangement.Helper
{
    public class AcessingUserData
    {
      
        string path = @"C:\Users\mhussain\Downloads\aaaa-main\aaaa-main\SchoolMangement\SchoolMangement\Model\SignInSignUpData.xml";
        public ObservableCollection<LogInSignUpData> VerifyingUser()
        {
            try
            {

                XmlSerializer serializer = new XmlSerializer(typeof(UserCollection));

                using (StreamReader reader = new StreamReader(path))
                {
                    var wrapper = (UserCollection)serializer.Deserialize(reader);

                    //Return the collection inside the wrapper
                    return wrapper?.Users ?? new ObservableCollection<LogInSignUpData>();


                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;

            }


        }
    }
}
