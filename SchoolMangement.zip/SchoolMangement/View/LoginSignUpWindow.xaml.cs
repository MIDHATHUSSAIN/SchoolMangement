﻿using SchoolMangement.ViewModel;

namespace SchoolMangement.View
{
    public partial class LoginSignUpWindow
    {
        public LoginSignUpWindow()
        {
            InitializeComponent();

            this.DataContext = new FormInputViewModel();
        }
    }
}
