﻿using System.Windows;

namespace SchoolMangement.View.UserControls.FormInputs
{   public partial class TopHeading 
    {
        public static readonly DependencyProperty TopHeadingText = DependencyProperty.Register("TopHeadingTxt", typeof(string), typeof(TopHeading), new PropertyMetadata(string.Empty));

        public string TopHeadingTxt
        {
            get {  return (string)GetValue(TopHeadingText);}
            set { SetValue(TopHeadingText, value); }
       }
        public TopHeading()
        {
            InitializeComponent();
        }
    }
}
