﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SchoolMangement.View.UserControls.FormInputs
{
    
    public partial class Password
    {
        public static readonly DependencyProperty LabelTextPropertyy =
        DependencyProperty.Register("LabelTextt", typeof(string), typeof(Password), new PropertyMetadata(string.Empty));
        public string LabelTextt
        {
            get { return (string)GetValue(LabelTextPropertyy); }
            set { SetValue(LabelTextPropertyy, value); }
        }



        public static readonly DependencyProperty PasswordValueProperty =
          DependencyProperty.Register("PasswordValue", typeof(string), typeof(Password),
              new FrameworkPropertyMetadata(string.Empty, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));

        public string PasswordValue
        {
            get => (string)GetValue(PasswordValueProperty);
            set => SetValue(PasswordValueProperty, value);
        }



        public Password()
        {
            InitializeComponent();
        }
    }
}
