﻿using SchoolMangement.Helper;
using System.Windows.Input;

namespace SchoolMangement.ViewModel
{
    class AddNewTeacherViewModel
    {
        public ICommand TeacherSaveButton { get; }

        public AddNewTeacherViewModel()
        {
            TeacherSaveButton = new RelayCommand(SavingTeacher);
        }

        public void SavingTeacher()
        {
            MessageBox.Show("I'm inside SavingTeacher");

        }
    }
}
