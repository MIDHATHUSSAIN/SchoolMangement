﻿using SchoolMangement.Classes;
using SchoolMangement.Helper;
using System.Windows;
using System.Windows.Input;

namespace SchoolMangement.ViewModel
{
    class AddNewStudentViewModel
    {
        public ICommand StudentSaveButton { get; }

        public Student StudentData { get; set; } = new Student();


        public AddNewStudentViewModel()
        {
            StudentSaveButton = new RelayCommand(SavingStudent);
          
        }

        public void SavingStudent()
        {
            AccessingStudentData acessingStudentData = new AccessingStudentData();
            acessingStudentData.SavingData(StudentData);
         
        }

        public void DeletingStudent()
        {
            AccessingStudentData acessingStudentData = new AccessingStudentData();
            acessingStudentData.DeletingData(StudentData);
        }

    }
}
