﻿using System.Collections.ObjectModel;
using System.Xml.Serialization;

namespace SchoolMangement.Classes
{
    [XmlRoot("Students")]
    public class StudentCollection
    {
        [XmlElement("Student")]
        public ObservableCollection<Student> Students { get; set; } = new ObservableCollection<Student>();

    }
}
