﻿using SchoolMangement.Helper;
using SchoolMangement.View.Pages;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;

namespace SchoolMangement.ViewModel
{
    public class TopBarViewModel : INotifyPropertyChanged
    {

        private string _role;
        public ICommand MoveToTeacher { get; }
        public ICommand MoveToStudent { get; }
        public ICommand MoveToAnnouncement { get; }
        public ICommand MoveToCourse { get; }

        private object _currentPage;

        public bool IsAdmin => Role == "Admin";
        public bool IsTeacher => Role == "Teacher";
        public bool IsStudent => Role == "Student";
        public string Role
        {
            get => _role;
            set { 
                _role = value; OnPropertyChanged();
               
                 }
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        public object CurrentPage
        {
            get => _currentPage;
            set { _currentPage = value; OnPropertyChanged(); }
        }
        public TopBarViewModel()
        {
            MoveToTeacher = new RelayCommand(MovingToTeacher);
            MoveToStudent = new RelayCommand(MovingToStudent);
        }
        public void MovingToTeacher()
        {
            try
            {
                CurrentPage = new AddNewTeacher();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

           
        }

        public void MovingToStudent()
        {
            CurrentPage = new AddNewStudent();
        }
        private void OnPropertyChanged([CallerMemberName] string PropertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(PropertyName));
        }
    }
}
