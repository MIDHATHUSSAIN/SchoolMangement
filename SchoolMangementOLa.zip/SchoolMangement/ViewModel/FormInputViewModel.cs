﻿using SchoolMangement.Classes;
using SchoolMangement.Helper;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using BC = BCrypt.Net.BCrypt;
namespace SchoolMangement.ViewModel
{
    public class FormInputViewModel: INotifyPropertyChanged
    {

        private readonly TopBarViewModel _topBarViewModel;

        private string _topHeading = "Sign In";
        AcessingUserData Ad = new AcessingUserData();
        public LogInSignUpData UserData { get; set; } = new LogInSignUpData();
        public string TopHeading
        {
            get => _topHeading;
            set { _topHeading = value; OnPropertyChanged(); }
        }

        public bool IsSignUpMode => TopHeading == "Sign Up";
        public bool IsSignInMode => TopHeading == "Sign In";
        public event PropertyChangedEventHandler? PropertyChanged;
        public ICommand SignUp { get;}
        public ICommand SignIn { get; }
        public ICommand SignOut { get; }

        public string ConformPassword { get; set; }
        public string UserName
        {
            get => UserData.UserName;
            set { UserData.UserName = value; OnPropertyChanged(); }
        }
        public string UserEmail
        {
            get => UserData.UserEmail;
            set { UserData.UserEmail = value; OnPropertyChanged(); }
        }
        public string UserPassword
        {
            get => UserData.UserPassword;
            set { UserData.UserPassword = value; OnPropertyChanged(); }
        }
        public FormInputViewModel(TopBarViewModel topBarViewModel)
        {
            _topBarViewModel = topBarViewModel;
            SignUp = new RelayCommand(MovingToSignUp);
            SignIn = new RelayCommand(MovingToSignIn);
            SignOut = new RelayCommand(MovingToSignOut);
        }

        public FormInputViewModel()
        {
        }

        public void MovingToSignUp()
        {   
                TopHeading = "Sign Up";
            OnPropertyChanged(nameof(IsSignUpMode));
            OnPropertyChanged(nameof(IsSignInMode));

            if (UserData.UserPassword != ConformPassword)
            {
                MessageBox.Show("Password and Confirm Password are not same");
                return;

            }
            Ad.SingingUp(UserData);

        }

        public void MovingToSignIn()
        {
            try
            {
                TopHeading = "Sign In";
                OnPropertyChanged(nameof(IsSignUpMode));
                OnPropertyChanged(nameof(IsSignInMode));

                ObservableCollection<LogInSignUpData> UserData = Ad.VerifyingUser();


                if (UserData != null)
                {

                    var user = UserData.FirstOrDefault(u => u.UserEmail == UserEmail);
                    if ((user != null))
                    {
                        bool isValid = BC.Verify(UserPassword, user.UserPassword);
                        if (isValid)
                        {
                            if (user.Role == "Admin")
                            {
                                _topBarViewModel.Role = "Admin";
                            }
                            if (user.Role == "Teacher")
                            {
                                _topBarViewModel.Role = "Teacher";
                            }
                            if (user.Role == "Student")
                            {
                                _topBarViewModel.Role = "Student";
                            }

                            MainWindow mainWin = new MainWindow();
                            mainWin.Show();
                            var loginWindow = System.Windows.Application.Current.Windows
                             .OfType<System.Windows.Window>()
                             .FirstOrDefault(w => w.IsActive || w.GetType().Name == "LoginSignUpWindow");
                            loginWindow?.Close();

                        }
                        else
                        {
                            MessageBox.Show("Invalid Password");
                        }
                    }

                }

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
           

        }

        public void MovingToSignOut()
        {
            TopHeading = "Sign In";
        }

        private void OnPropertyChanged([CallerMemberName] string PropertyName = null)
            {
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(PropertyName));
        }
    }
}
