﻿using SchoolMangement.ViewModel;

namespace SchoolMangement.View
{
    public partial class LoginSignUpWindow
    {
        public LoginSignUpWindow()
        {
            InitializeComponent();

            var topBarVM = new TopBarViewModel();
            this.DataContext = new FormInputViewModel(topBarVM);
        }
    }
}
