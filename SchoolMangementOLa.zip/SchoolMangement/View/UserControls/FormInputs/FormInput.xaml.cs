﻿using System.Windows;

namespace SchoolMangement.View.UserControls.FormInputs
{

    public partial class FormInput 
    {
        public static readonly DependencyProperty LabelTextProperty =
        DependencyProperty.Register("LabelText", typeof(string), typeof(FormInput), new PropertyMetadata(string.Empty));
        public string LabelText
        {
            get { return (string)GetValue(LabelTextProperty); }
            set { SetValue(LabelTextProperty, value); }
        }

        public static readonly DependencyProperty TextValueProperty =
           DependencyProperty.Register("TextValue", typeof(string), typeof(FormInput),
               new FrameworkPropertyMetadata(string.Empty, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));

        public string TextValue
        {
            get => (string)GetValue(TextValueProperty);
            set => SetValue(TextValueProperty, value);
        }

        public FormInput()
        {
            InitializeComponent();
            
        }
    }
}
