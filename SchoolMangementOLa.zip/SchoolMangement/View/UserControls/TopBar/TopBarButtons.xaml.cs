﻿using SchoolMangement.ViewModel;
using System.Windows;

namespace SchoolMangement.View.UserControls.TopBar
{
    public partial class TopBarButtons 
    {
        public TopBarButtons()
        {
            InitializeComponent();
            this.DataContext = new TopBarViewModel();
        }

        
    }
}
