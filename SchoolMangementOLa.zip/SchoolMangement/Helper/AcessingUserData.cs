﻿using DevExpress.Charts.Designer.Native;
using DevExpress.Internal;
using DevExpress.Map.Kml.Model;
using DevExpress.Xpf.Gauges;
using SchoolMangement.Classes;
using System.Collections.ObjectModel;
using System.IO;
using System.Xml.Serialization;
using BC = BCrypt.Net.BCrypt;
namespace SchoolMangement.Helper
{
    public class AcessingUserData
    {
      
        string path = @"C:\Users\mhussain\Downloads\SchoolMangementHomiii\SchoolMangement\SchoolMangement\Model\SignInSignUpData.xml";
        string path2 = @"C:\Users\mhussain\Downloads\SchoolMangementHomiii\SchoolMangement\SchoolMangement\Model\TeacherData.xml";
        string path3 = @"C:\Users\mhussain\Downloads\SchoolMangementHomiii\SchoolMangement\SchoolMangement\Model\StudentsData.xml";
        XmlRootAttribute xRoot = new XmlRootAttribute();
        ObservableCollection<LogInSignUpData> Users;
        public AcessingUserData()
        {
            XmlSerializer serializer = new XmlSerializer(typeof(UserCollection));

            using (StreamReader reader = new StreamReader(path))
            {
                var wrapper = (UserCollection)serializer.Deserialize(reader);

                Users = wrapper?.Users ?? new ObservableCollection<LogInSignUpData>();


            }
        }
        public ObservableCollection<LogInSignUpData> VerifyingUser()
        {
            try
            {
                return Users;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;

            }


        }

        public void SingingUp(LogInSignUpData UserData)
        {
            try
            {   if(UserData.UserEmail == null)
                {
                    return;
                }
                xRoot.ElementName = "Teachers";
                xRoot.IsNullable = true;
                XmlSerializer serializer = new XmlSerializer(typeof(ObservableCollection<Teacher>), xRoot);
                using (StreamReader reader = new StreamReader(path2))
                {
                    var Teachers = (ObservableCollection<Teacher>)serializer.Deserialize(reader);

                    
                    if (Teachers != null)
                    {
                        var a = Teachers.Where(x => x.TeacherEmail == UserData.UserEmail);
                        if(a.Any())
                        {
                            var c = Users.Where(x => x.UserEmail == UserData.UserEmail);
                            if(c.Any())
                            {
                               MessageBox.Show("This email is already used,Kidnly Contact Admin");
                            }
                            else
                            {
                                string passwordToSave = BC.HashPassword(UserData.UserPassword);
                                UserData.UserPassword = passwordToSave;
                                UserData.Role = "Teacher";
                                Users.Add(UserData);
                                XmlSerializer userSerializer = new XmlSerializer(typeof(UserCollection));
                                using (StreamWriter writer = new StreamWriter(path))
                                {
                                    userSerializer.Serialize(writer, new UserCollection { Users = Users });

                                }
                                System.Windows.MessageBox.Show("You Can Sign In Now");
                            }
                        }
                        else
                        {
                            xRoot.ElementName = "Students";
                            xRoot.IsNullable = true;
                            XmlSerializer serializerr = new XmlSerializer(typeof(ObservableCollection<Student>), xRoot);
                            using (StreamReader readerr = new StreamReader(path3))
                            {
                                var Students = (ObservableCollection<Student>)serializerr.Deserialize(readerr);
                                if (Students != null)
                                {
                                    var b = Students.Where(x => x.StudentEmail == UserData.UserEmail).ToList();
                                    if (b.Any())
                                    {
                                        var c = Users.Where(x => x.UserEmail == UserData.UserEmail);
                                        if (c.Any())
                                        {
                                            MessageBox.Show("This email is already used,Kidnly Contact Admin");
                                        }
                                        else
                                        {
                                            string passwordToSave = BC.HashPassword(UserData.UserPassword);
                                            UserData.UserPassword = passwordToSave;
                                            UserData.UserName = b[0].StudentName;
                                            UserData.Role = "Student";
                                            Users.Add(UserData);
                                            XmlSerializer userSerializer = new XmlSerializer(typeof(UserCollection)); 
                                            using (StreamWriter writer = new StreamWriter(path)) 
                                            { 
                                                userSerializer.Serialize(writer, new UserCollection { Users = Users }); 
                                            
                                            }
                                            System.Windows.MessageBox.Show("You Can Sign In Now");
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show("You Can't Sing Up ,Kidnly Contact Admin");
                                    }
                                }
                            }

                        }
                    }
                   
                        

                        
                    
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }
    }
}
