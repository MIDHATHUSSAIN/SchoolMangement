﻿using SchoolMangement.Classes;
using System.Collections.ObjectModel;
using System.IO;
using System.Xml.Serialization;

namespace SchoolMangement.Helper
{
    public class AccessingTeacherData
    {
        string path = @"C:\Users\mhussain\Downloads\SchoolMangementHomiii\SchoolMangement\SchoolMangement\Model\TeacherData.xml";
        XmlRootAttribute xRoot = new XmlRootAttribute();
        ObservableCollection<Teacher> teachers;
        public ObservableCollection<Teacher> RetrivingData()
        {
            try
            {
                xRoot.ElementName = "Teachres";
                xRoot.IsNullable = true;
                XmlSerializer serializer = new XmlSerializer(typeof(ObservableCollection<Teacher>), xRoot);
                using (StreamReader reader = new StreamReader(path))
                {
                    var data = (ObservableCollection<Teacher>)serializer.Deserialize(reader);

                    return data;
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }

        }

        public void SavingData(Teacher TeacherData)
        {
            try
            {
                xRoot.ElementName = "Teachers";
                xRoot.IsNullable = true;
                XmlSerializer serializer = new XmlSerializer(typeof(ObservableCollection<Teacher>), xRoot);

                if (File.Exists(path))
                {
                    using (StreamReader reader = new StreamReader(path))
                    {
                        teachers = (ObservableCollection<Teacher>)serializer.Deserialize(reader);
                    }
                }

                var a = teachers.Where(x => x.TeacherEmail == TeacherData.TeacherEmail).FirstOrDefault();
                if (a != null)
                {
                    MessageBox.Show("Teacher with this email already exists.");
                    return;
                }
                else
                {
                    teachers.Add(TeacherData);
                    using (StreamWriter writer = new StreamWriter(path))
                    {
                        serializer.Serialize(writer, teachers);

                    }
                    System.Windows.MessageBox.Show("Teacher Saved Successfully!");
                }

            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
                MessageBox.Show("Somthing went wrong");
            }

        }

        public void UpdatingData(Teacher TeacherData)
        {
            try
            {

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public void DeletingData(Teacher TeacherData)
        {
            try
            {
                xRoot.ElementName = "Teachers";
                xRoot.IsNullable = true;
                XmlSerializer serializer = new XmlSerializer(typeof(ObservableCollection<Teacher>), xRoot);

                if (File.Exists(path))
                {
                    using (StreamReader reader = new StreamReader(path))
                    {
                        teachers = (ObservableCollection<Teacher>)serializer.Deserialize(reader);
                    }
                }

                var a = teachers.Where(x => x.TeacherEmail == TeacherData.TeacherEmail).FirstOrDefault();
                if (a != null)
                {
                    teachers.Remove(a);
                    using (StreamWriter writer = new StreamWriter(path))
                    {
                        serializer.Serialize(writer, teachers);

                    }
                    System.Windows.MessageBox.Show("Teacher Deleted Successfully!");
                }

            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
                MessageBox.Show("Somthing went wrong");
            }

        }

    }
}
