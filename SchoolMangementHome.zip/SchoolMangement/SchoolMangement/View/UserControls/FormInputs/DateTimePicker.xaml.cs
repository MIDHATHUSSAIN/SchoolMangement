﻿using System.Windows;

namespace SchoolMangement.View.UserControls.FormInputs
{

    public partial class DateTimePicker 
    {
        public static readonly DependencyProperty TextValueProperty =
          DependencyProperty.Register("TextValue", typeof(string), typeof(DateTimePicker),
              new FrameworkPropertyMetadata(string.Empty, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));

        public string TextValue
        {
            get => (string)GetValue(TextValueProperty);
            set => SetValue(TextValueProperty, value);
        }
        public DateTimePicker() => InitializeComponent();
    }
}
