﻿using SchoolMangement.Classes;
using SchoolMangement.Helper;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;

namespace SchoolMangement.ViewModel
{
    internal class MainWindowViewModel :INotifyPropertyChanged
    {
        //string path = @"C:\\Users\\mhussain\\Downloads\\aaaa-main\\aaaa-main\\SchoolMangement\\SchoolMangement\\Model\\StudentsData.xml";

        AccessingStudentData Ad = new AccessingStudentData();

        private ObservableCollection<Student> students;

        public event PropertyChangedEventHandler? PropertyChanged;

        public ObservableCollection<Student> Students
        {
            get { return students; }
            set { students = value;
               OnPropertyChanged();
            }
        }
        public ICommand Save { get; }

        public ICommand GetData { get; }

        public MainWindowViewModel()
        {
            Save = new RelayCommand(SaveData);
            GetData = new RelayCommand(RetriveData);
        }

        public void SaveData()
        {
            //Ad.SavingData();
        }

        public void DeleteData()
        {
            //Ad.DeletingData();
        }
        public void UpdateData()
        {
            //Ad.UpdatingData();
        }
        public void RetriveData()
        {
            //Students = Ad.RetrivingData("Students",path);
        }

        private void OnPropertyChanged([CallerMemberName] string PropertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(PropertyName));

        }
    }
}
