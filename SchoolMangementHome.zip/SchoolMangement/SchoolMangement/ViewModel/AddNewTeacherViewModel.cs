﻿using SchoolMangement.Classes;
using SchoolMangement.Helper;
using System.Windows.Input;

namespace SchoolMangement.ViewModel
{
    class AddNewTeacherViewModel
    {
        public ICommand TeacherSaveButton { get; }

        public Teacher TeacherData { get; set; } = new Teacher();
        public AddNewTeacherViewModel()
        {
            TeacherSaveButton = new RelayCommand(SavingTeacher);
        }

        public void SavingTeacher()
        {
            AccessingTeacherData acessingTeacherData = new AccessingTeacherData();
            acessingTeacherData.SavingData(TeacherData);
           

        }

        public void DeletingStudent()
        {
            AccessingTeacherData acessingTeacherData = new AccessingTeacherData();
            acessingTeacherData.DeletingData(TeacherData);
        }
    }
}
