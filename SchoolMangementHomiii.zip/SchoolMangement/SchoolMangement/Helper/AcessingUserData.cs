﻿using DevExpress.Map.Kml.Model;
using SchoolMangement.Classes;
using System.Collections.ObjectModel;
using System.IO;
using System.Xml.Serialization;

namespace SchoolMangement.Helper
{
    public class AcessingUserData
    {
      
        string path = @"D:\Downloads\SchoolMangement-main\SchoolMangement-main\SchoolMangement\SchoolMangement\Model\SignInSignUpData.xml";

        XmlRootAttribute xRoot = new XmlRootAttribute();
        ObservableCollection<Teacher> teachers;
        public ObservableCollection<LogInSignUpData> VerifyingUser()
        {
            try
            {

                XmlSerializer serializer = new XmlSerializer(typeof(UserCollection));

                using (StreamReader reader = new StreamReader(path))
                {
                    var wrapper = (UserCollection)serializer.Deserialize(reader);

                    //Return the collection inside the wrapper
                    return wrapper?.Users ?? new ObservableCollection<LogInSignUpData>();


                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;

            }


        }

        public ObservableCollection<LogInSignUpData> SingingUp(LogInSignUpData UserData)
        {
            try
            {
                xRoot.ElementName = "Teachres";
                xRoot.IsNullable = true;
                XmlSerializer serializer = new XmlSerializer(typeof(ObservableCollection<Teacher>), xRoot);
                using (StreamReader reader = new StreamReader(path))
                {
                    var Teachers = (ObservableCollection<Teacher>)serializer.Deserialize(reader);

                    //return data;

                    if(Teachers != null)
                    {
                        var a = Teachers.Where(x => x.TeacherEmail == UserData.UserEmail);
                    }
                    else
                    {
                        xRoot.ElementName = "Teachres";
                        xRoot.IsNullable = true;
                        XmlSerializer serializerr = new XmlSerializer(typeof(ObservableCollection<Student>), xRoot);
                        using (StreamReader readerr = new StreamReader(path))
                        {
                            var Students = (ObservableCollection<Student>)serializerr.Deserialize(readerr);
                        }   
                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }
    }
}
